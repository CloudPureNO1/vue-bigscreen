<template>
    <div>
        <Vueditor class="main-cls"></Vueditor>
    </div>
</template>
<script>


export default {

}
</script>

<style scoped>
.main-cls {
    height: 10rem;
    width: 30rem;
}
</style>